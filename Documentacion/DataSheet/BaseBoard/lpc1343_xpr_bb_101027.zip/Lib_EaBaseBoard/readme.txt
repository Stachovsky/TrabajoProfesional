This library project contains code to handle various peripherals on the
Embedded Artists LPCXpresso Base Board.





