/*****************************************************************************
 *   This example shows how to access an MMC/SD card
 *
 *   Copyright(C) 2009, Embedded Artists AB
 *   All rights reserved.
 *
 ******************************************************************************/



#include "mcu_regs.h"
#include "type.h"
#include "uart.h"
#include "stdio.h"
#include "timer32.h"

#include "gpio.h"
#include "ssp.h"

#include "diskio.h"
#include "ff.h"


static FILINFO Finfo;
static FATFS Fatfs[1];
static uint8_t buf[64];

void SysTick_Handler(void) {
    disk_timerproc();
}


/* Main Program */

int main (void) {
    DSTATUS stat;
    DWORD p2;
    WORD w1;
    BYTE res, b1;
    DIR dir;

    int i = 0;

    GPIOInit();
    init_timer32(0, 10);

    UARTInit(115200);
    UARTSendString((uint8_t*)"MMC/SD example\r\n");

    SSPInit();

    SysTick_Config(SystemCoreClock / 100);

    if ( !(SysTick->CTRL & (1<<SysTick_CTRL_CLKSOURCE_Msk)) )
    {
      /* When external reference clock is used(CLKSOURCE in
      Systick Control and register bit 2 is set to 0), the
      SYSTICKCLKDIV must be a non-zero value and 2.5 times
      faster than the reference clock.
      When core clock, or system AHB clock, is used(CLKSOURCE
      in Systick Control and register bit 2 is set to 1), the
      SYSTICKCLKDIV has no effect to the SYSTICK frequency. See
      more on Systick clock and status register in Cortex-M3
      technical Reference Manual. */
      LPC_SYSCON->SYSTICKCLKDIV = 0x08;
    }

    delay32Ms(0, 500);

    stat = disk_initialize(0);
    if (stat & STA_NOINIT) {
        UARTSendString((uint8_t*)"MMC: not initialized\r\n");
    }

    if (stat & STA_NODISK) {
        UARTSendString((uint8_t*)"MMC: No Disk\r\n");
    }

    if (stat != 0) {
        return 1;
    }

    UARTSendString((uint8_t*)"MMC: Initialized\r\n");

    if (disk_ioctl(0, GET_SECTOR_COUNT, &p2) == RES_OK) {
        i = sprintf((char*)buf, "Drive size: %d \r\n", p2);
        UARTSend(buf, i);
    }

    if (disk_ioctl(0, GET_SECTOR_SIZE, &w1) == RES_OK) {
        i = sprintf((char*)buf, "Sector size: %d \r\n", w1);
        UARTSend(buf, i);
    }

    if (disk_ioctl(0, GET_BLOCK_SIZE, &p2) == RES_OK) {
        i = sprintf((char*)buf, "Erase block size: %d \r\n", p2);
        UARTSend(buf, i);
    }

    if (disk_ioctl(0, MMC_GET_TYPE, &b1) == RES_OK) {
        i = sprintf((char*)buf, "Card type: %d \r\n", b1);
        UARTSend(buf, i);
    }

    res = f_mount(0, &Fatfs[0]);
    if (res != FR_OK) {
        i = sprintf((char*)buf, "Failed to mount 0: %d \r\n", res);
        UARTSend(buf, i);
        return 1;
    }

    res = f_opendir(&dir, "/");
    if (res) {
        i = sprintf((char*)buf, "Failed to open /: %d \r\n", res);
        UARTSend(buf, i);
        return 1;
    }

    for(;;) {
        res = f_readdir(&dir, &Finfo);
        if ((res != FR_OK) || !Finfo.fname[0]) break;

        UARTSendString((uint8_t*)&(Finfo.fname[0]));
        UARTSendString((uint8_t*)"\r\n");

    }


    while(1);


}
