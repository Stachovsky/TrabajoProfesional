

This example is based on NXPs USBHostLite project with a few 
changes from Code Red.

  http://www.standardics.nxp.com/support/software/usb.host.msc/
  
The example only works with FAT16 formatted USB memory sticks and
will read a file named msread.txt and copy the content to a file
named mswrite.txt

Status information will be printed via the UART. Connect a terminal 
application to the board with a baud rate of 115200.






