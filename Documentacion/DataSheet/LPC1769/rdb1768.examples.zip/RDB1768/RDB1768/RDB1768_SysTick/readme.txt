Code Red Technologies RDB1768 Board - SysTick Demo
==================================================

This simple project shows how the SysTick timer built in
to the NVIC of the Cortex-M3 processor core contained within
the LPC1768 microcontroller can be set up.

Download the project to the board and run it. Each time you
then suspend execution, you should be able to see the counter
variables contained within the main while loop and within
the Systick interupt handler being incremented.



