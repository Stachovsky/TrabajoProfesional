Code Red Technologies RDB1768 Board - LCD Demo
==============================================

This demonstration project shows how the LCD screen on the RDB1768
can be used. The demonstration is broken up into three parts, with
a short pause between each part.

The first part prints the Code Red logo to the screen and prints 
several strings and individual characters to the screen.

The second part uses a number of provided primitives for drawing
various lines and shapes to the screen.

The third part displays a very simple animation, consisting of the
Code Red logo moving down, then back up the screen.




