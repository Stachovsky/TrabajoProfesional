//*****************************************************************************
//   +--+       
//   | ++----+   
//   +-++    |  
//     |     |  
//   +-+--+  |   
//   | +--+--+  
//   +----+    Copyright (c) 2009 Code Red Technologies Ltd. 
//
// logo.c contains a function to print the graphical logo
// defined in logocr.h to the LCD.
//
// Software License Agreement
// 
// The software is owned by Code Red Technologies and/or its suppliers, and is 
// protected under applicable copyright laws.  All rights are reserved.  Any 
// use in violation of the foregoing restrictions may subject the user to criminal 
// sanctions under applicable laws, as well as to civil liability for the breach 
// of the terms and conditions of this license.
// 
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD. 

#include "logoCR.h"
#include "lcd.h"

// Displays the graphical logo at the location (x,y).
// Note that this routine currently assumes that logo is
// 128 pixels wide, and hence x should be 0. It also
// assumes that the height of the logo is 32 pixels.
// However the function could be easily converted to
// display a logo of different dimensions

void PlotLogo(int x, int y)
{
	int i,j,r,g,b,ch,col24;
	
	for (j=0; j<32; j++) // col
	{
		for (i=0; i<128; i++) // row
		{
			ch = header_data[i+(j*128)];
			r= header_data_cmap[ch][0];
			g= header_data_cmap[ch][1];
			b= header_data_cmap[ch][2];
			col24= (r<<16)|(g<<8)|b;
			LCD_PlotPoint(x+i,y+j,TRANSLATE24BIT_TO_RGB565(col24));//color_map(g_pucLogo[i][j]));		
		}
	}
}
