//*****************************************************************************
//   +--+       
//   | ++----+   
//   +-++    |  
//     |     |  
//   +-+--+  |   
//   | +--+--+  
//   +----+    Copyright (c) 2009 Code Red Technologies Ltd. 
//
// main.c calls a number of functions to demonstrate the use of the
// LCD display on the RDB1768 development board.
//
//
// Software License Agreement
// 
// The software is owned by Code Red Technologies and/or its suppliers, and is 
// protected under applicable copyright laws.  All rights are reserved.  Any 
// use in violation of the foregoing restrictions may subject the user to criminal 
// sanctions under applicable laws, as well as to civil liability for the breach 
// of the terms and conditions of this license.
// 
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD. 

#include "NXP/LPC17xx/type.h"
#include "NXP/LPC17xx/LPC17xx.h"
#include "NXP/LPC17xx/target.h"
#include "lcd_driver.h"
#include "lcd.h"
#include "logo.h"



// Function to add short delays in writing things to the LCD.
void main_delay(int n)
{
   volatile int d;
   for (d=0; d<n*3000; d++){}
}

int main(void)
{
	int yloc;  // temp used for part 3 of demo
	
	// Set up general system / board / PLL / clocks ....	
	CLKSRCSEL |= 0x40;
	TargetResetInit();
	
	// Initialize the ST7637 LCD Controller/driver for use
	LCDdriver_initialisation();
	
	// Continuously loop through the LCD demonstration
	while(1)
	{	
		// *************************************
		// ** LCD Demo part 1 - Logo and text **
		// *************************************
		
		PlotLogo(0,0);				// Draw the Code Red logo onto the LCD			
		main_delay(2500);			// Small delay 
		
		// Print some strings onto the LCD
		LCD_PrintString(10,40,"It's CodeRed's",14, COLOR_RED);
		LCD_PrintString(14,60,"RDB1768 board",13, COLOR_RED);
		LCD_PrintString(36,80,"LCD Demo",8, COLOR_RED);	
		main_delay(2500);			// Small delay 
		
		// Print a countdown on screen using individual characters
		LCD_PrintChar(60, 100, '3',COLOR_YELLOW);	
		main_delay(2500);			// Small delay
		LCD_PrintChar(60, 100, '2',COLOR_YELLOW);	
		main_delay(2500);			// Small delay
		LCD_PrintChar(60, 100, '1',COLOR_YELLOW);
		main_delay(2500);			// Small delay
		
		LCD_ClearScreen();	// Clear screen ready for next part of demo

		
		// *****************************************************
		// ** LCD Demo part 2 - Primitives for drawing shapes **
		// *****************************************************
		
		// Print info at top of screen
		LCD_PrintString(0,0,"Drawing shapes",14, COLOR_RED);	
		main_delay(1000); 			// Small delay
		
		// Draw an unfilled rectangle
		LCD_Rect (0, 127, 16, 127, COLOR_RED);	
		main_delay(1000); 			// Small delay
		
		// Draw a filled rectangle
		LCD_FilledRect (10,117,26,117,COLOR_WHITE);	
		main_delay(1000); 			// Small delay

		// Draw an unfilled circle
		LCD_Circle (64, 72, 30, COLOR_BLACK);
	
		main_delay(1000); 			// Small delay

		// Draw a filled circle
		LCD_FilledCircle (64, 72, 20, COLOR_TEAL);	
		main_delay(1000); 			// Small delay

		// Draw two diagonal lines across unfilled rectangle
		LCD_Line (0,127,16,127,COLOR_RED);
		main_delay(1000); 			// Small delay
		LCD_Line (0,127,127,16,COLOR_RED);
		main_delay(3000); 			// Small delay
		
		LCD_ClearScreen();	// Clear screen ready for next part of demo

		
		// ****************************************
		// ** LCD Demo part 3 - Simple animation **
		// ****************************************
		
		// Print info at top of screen		
		LCD_PrintString(0,0,"Simple animation",16, COLOR_RED);	

		
		// Print logo in initial position underneath text
		PlotLogo(0,16);

		main_delay(2000);
		
		// Now repeatedly print logo to screen, each time one line
		// lower down the screen, and each time erasing the top line
		// of the previous copy of the logo (the other lines will be 
		// overwritten by the new version. Repeat until we are at the
		// bottom of the screen (allowing for logo being 32 pixels high,
		// and last line of screen = 127 => line 95.
		
		for (yloc = 17; yloc < 95; yloc++)  
		{
			LCD_FilledRect (0,127,yloc-1,yloc-1,COLOR_BLACK);			
			PlotLogo(0,yloc);			
		}
		
		main_delay(500);		// Small delay

		// Now repeatedly print the logo moving back up the screen
		
		for (yloc = 94; yloc > 16; yloc--)
		{
			LCD_FilledRect (0,127,yloc+33,yloc+33,COLOR_BLACK);			
			PlotLogo(0,yloc);			
		}

		main_delay(2000);		// Small delay
		
		LCD_ClearScreen(); // Clear screen ready for restarting the demo

	}
	return 0 ;
}
