//*****************************************************************************
//   +--+       
//   | ++----+   
//   +-++    |  
//     |     |  
//   +-+--+  |   
//   | +--+--+  
//   +----+    Copyright (c) 2009 Code Red Technologies Ltd. 
//
// RDB1768_AUDIO.c
// Uses the interrupt driven I2C driver state machine to configure the part.
//
// Software License Agreement
// 
// The software is owned by Code Red Technologies and/or its suppliers, and is 
// protected under applicable copyright laws.  All rights are reserved.  Any 
// use in violation of the foregoing restrictions may subject the user to criminal 
// sanctions under applicable laws, as well as to civil liability for the breach 
// of the terms and conditions of this license.
// 
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD. 
//
//*****************************************************************************

#include "RDB1768_AUDIO.h"
#include "NXP/LPC17xx/LPC17xx.h"
#include "NXP\LPC17xx\type.h"
#include "i2c.h"

#include "delay.h"

extern volatile DWORD I2CCount;
extern volatile BYTE I2CMasterBuffer[BUFSIZE];
extern volatile DWORD I2CCmd, I2CMasterState;
extern volatile DWORD I2CReadLength, I2CWriteLength;


#define CS42L51_ADDR 0x94			//I2C address of the Codec

// Sub-addresses of registers within the Codec
#define CS42L51_ID_01 0x01
#define CS42L51_PWRCTL_02 0x02
#define CS42L51_BEEPCTL_14 0x14
#define CS42L51_DACCTL_09 0x09
#define CS42L51_IFCTL_04 0x04
#define CS42L51_PCMX_11 0x11

#define INC_BIT 0x80


// Clear the I2C buffer
static void vF_ClearBuffer(void)
{
	int i;
	
	for ( i = 0; i < BUFSIZE; i++ )	/* clear buffer */
	{
		I2CMasterBuffer[i] = 0;
	}
}

// Read a Codec register
static BYTE BF_ReadCodecReg(BYTE B_MAP)
{	
	vF_ClearBuffer();
	I2CWriteLength = 1;
	I2CReadLength = 1;
	I2CMasterBuffer[0] = CS42L51_ADDR;
	I2CMasterBuffer[1] = B_MAP;
	I2CMasterBuffer[2] = CS42L51_ADDR | RD_BIT;

	I2CEngine();
	
	return I2CMasterBuffer[3];
}

// Write a Codec register
static void vF_WriteCodecReg(BYTE B_MAP, BYTE B_Value)
{
	vF_ClearBuffer();
	I2CWriteLength = 2;
	I2CReadLength = 0;
	I2CMasterBuffer[0] = CS42L51_ADDR;
	I2CMasterBuffer[1] = B_MAP;
	I2CMasterBuffer[2] = B_Value;
	I2CEngine();	
}

// Initialize the Codec so it talks I2S
static void vF_CodecInit(void)
{	
	if ( I2CInit( (DWORD)I2CMASTER ) == FALSE )	/* initialize I2c */
	{
		while ( 1 );				/* Fatal error */
	}
	
	// Have to write to the PDN register to stop it going into 'hardware mode'
	vF_WriteCodecReg(CS42L51_PWRCTL_02, 0x1);
	
	vF_WriteCodecReg(CS42L51_IFCTL_04, 0x0c);
	vF_WriteCodecReg(CS42L51_PCMX_11, 0x00);
	vF_WriteCodecReg(CS42L51_DACCTL_09, 0x00);
	vF_WriteCodecReg(CS42L51_PWRCTL_02, 0x00);
}

// Initialize all Audio components
void vfAudioInit(void)
{	
	// Put the codec in reset - NCODEC_RESET - P0.10
	FIO0DIR |= (1<<10);
	FIO0CLR |= (1<<10);

	delay (2000);
	
	// Bring it out of reset
	FIO0SET |= (1<<10);
	
	delay (2000);
	
	// Init the ctrl regs in the codec using I2C
	vF_CodecInit();
	
	// Switch power on I2S
	PCONP |= (1 << 27);
	
	// Set Peripheral clock up
	PCLKSEL1 &= ~(3 << 22);
	PCLKSEL1 |= (3 << 22);	//CCLK/8
	
	// Use the I2S fractional divider to create something useful
	// 44.1KHz * 256 = 11.2896MHz
	// 48KHz * 256 = 12.288MHz
	
	// For something close to Fs=44.1KHz
	// 48MHz/2= 24MHz.
	// 24MHz / 11.2896MHz = 2.12585 ~= 17/8
	
	// For something close to Fs=48KHz
	// 48MHz/2= 24MHz.
	// 24MHz / 12.288MHz = 1.953125 = 125/64
	
	I2SRXRATE = (1<<8) | (1);
	// P0.7 = I2STX_CLK - the bit clock
	PINSEL0 |= (1<<14);
	// P0.8 = I2STX_WS - the word clock
	PINSEL0 |= (1<<16);
	// P0.9 = I2STX_SD - data to codec
	PINSEL0 |= (1<<18);
	// P0.25 = I2SRX_SDA - data from codec
	PINSEL1 |= (2<<18);
		
	// Make P4.28 RX_MCLK output 
	PINSEL9 |= (1<<24);
	PINSEL9 |= (1<<26);
	
	// Switch on the RX MCLK
	I2SRXMODE = (1<<3);
	// and make TX MCLK sourced from RX MCLK
	I2STXMODE = 0x2;
	// 256/4 = 64 bits per frame
	I2STXBITRATE = 3;
	I2SRXBITRATE = 3;
	
	// RESET I2S
	I2SDAO = (1<<4) | (1<<3);
	I2SDAI = (1<<4) | (1<<3);

	// CS codec works in 32-bit mode.
	I2SDAI = 0x3 | (0x1f<<6);
	I2SDAO = 0x3 | (0x1f<<6);

	
}
