#ifndef RDB1768_AUDIO_H_
#define RDB1768_AUDIO_H_

#include "NXP/LPC17xx/type.h"

void vfAudioInit(void);
void vF_ReadCodecRegs(BYTE *pB_Dest);
void vF_Beep(void);

#endif /*RDB1768_AUDIO_H_*/
