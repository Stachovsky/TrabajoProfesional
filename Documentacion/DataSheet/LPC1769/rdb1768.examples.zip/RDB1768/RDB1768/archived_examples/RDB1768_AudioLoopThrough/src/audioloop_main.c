//*****************************************************************************
//   +--+       
//   | ++----+   
//   +-++    |  
//     |     |  
//   +-+--+  |   
//   | +--+--+  
//   +----+    Copyright (c) 2009 Code Red Technologies Ltd. 
//
// AudioLoopThrough example project for RDB1768 development board
//
// Software License Agreement
// 
// The software is owned by Code Red Technologies and/or its suppliers, and is 
// protected under applicable copyright laws.  All rights are reserved.  Any 
// use in violation of the foregoing restrictions may subject the user to criminal 
// sanctions under applicable laws, as well as to civil liability for the breach 
// of the terms and conditions of this license.
// 
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD. 
//
//*****************************************************************************
#include "NXP\LPC17xx\type.h"
#include "NXP/LPC17xx/LPC17xx.h"
#include "RDB1768_AUDIO.h"
#include "NXP\LPC17xx\target.h"



unsigned long __attribute__((naked)) CPUcpsie(void)
{
    unsigned long ulRet;

    //
    // Read PRIMASK and enable interrupts.
    //
    __asm("    mrs     %0, PRIMASK\n"
          "    cpsie   i\n"
          "    bx      lr\n"
          : "=r" (ulRet));

    return(ulRet);
}


int main(void)
{
	int i_TxFIFOLevel, i_RxFIFOLevel;
		
	// Main system setup
	TargetResetInit();
	
	// Initialize the Audio Codec through I2C
	vfAudioInit();
	
	unsigned long int ul_ADC_Val = 0;

	// Start global interrupts for the I2C driver
	CPUcpsie();
	while(1)
	{
		i_RxFIFOLevel = (I2SSTATE>>8) & 0X1f;
		if(i_RxFIFOLevel>4)
		{
			ul_ADC_Val = I2SRXFIFO;
		}
		
		i_TxFIFOLevel = (I2SSTATE>>16) & 0x1f;
		
		if(i_TxFIFOLevel<4)
		{
			I2STXFIFO = ul_ADC_Val;
		}				
	}
	
	return 0 ;
}
