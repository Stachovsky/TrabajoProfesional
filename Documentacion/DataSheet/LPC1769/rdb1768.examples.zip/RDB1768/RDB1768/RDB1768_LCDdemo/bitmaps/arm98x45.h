extern unsigned int arm98x45_width;
extern unsigned int arm98x45_height;
extern const unsigned short arm98x45_pixel_data [];
