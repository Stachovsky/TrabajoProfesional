extern unsigned int codered128x37_width;
extern unsigned int codered128x37_height;
extern const unsigned short codered128x37_pixel_data [];
