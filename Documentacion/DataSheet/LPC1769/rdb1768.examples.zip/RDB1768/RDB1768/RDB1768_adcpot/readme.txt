Code Red Technologies RDB1768 Board - ADC Potentiometer Demo
============================================================

This demonstration project show how the potentiometer on the
RDB1768 can be read using the analogue to digital convertor
built in the the LPC1768 microcontroller.

The project uses the 'semihosting' option in the debug
configuration. This allows the'printf' messages from the
target to display the last value read from the potentiometer
in the Red Suite Console Window. To change the value, simply
rotate the potentiometer.


