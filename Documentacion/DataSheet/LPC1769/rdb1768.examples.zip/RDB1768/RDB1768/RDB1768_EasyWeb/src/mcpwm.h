/*****************************************************************************
 *   mcpwm.h:  Header file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2008, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2008.09.16  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __MCPWM_H 
#define __MCPWM_H

typedef struct {
  DWORD channelType;
  DWORD channelPolarity;
  DWORD channelDeadtimeEnable;
  DWORD channelDeadtimeValue;
  DWORD channelUpdateEnable;
  DWORD channelSingleshotEnable;
  DWORD channelTimercounterValue;
  DWORD channelPeriodValue;
  DWORD channelPulsewidthValue;
} MCPWM_CHANNEL_SETUP_T;

void MCPWMIrqHandler(void);
DWORD MCPWM_Init(DWORD channelNum, MCPWM_CHANNEL_SETUP_T * channelSetup);
DWORD MCPWM_WriteToShadow(DWORD channelNum, MCPWM_CHANNEL_SETUP_T * channelSetup);
void MCPWM_CaptureEvent(DWORD channelNum, DWORD captureEvent, DWORD timerReset, DWORD hncEnable);
void MCPWM_countControl(DWORD channelNum, DWORD countMode, DWORD captureEvent);
void MCPWM_Start(DWORD channel0, DWORD channel1, DWORD channel2);
void MCPWM_Stop(DWORD channel0, DWORD channel1, DWORD channel2);
void MCPWM_acMode(DWORD acMode);
void MCPWM_dcMode(DWORD dcMode, DWORD outputInvered, DWORD outputPattern);

#endif /* end __MCPWM_H */
/****************************************************************************
**                            End Of File
****************************************************************************/
