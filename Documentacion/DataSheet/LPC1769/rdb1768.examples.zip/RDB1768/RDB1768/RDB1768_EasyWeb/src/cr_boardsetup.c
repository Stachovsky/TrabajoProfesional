//*****************************************************************************
//   +--+       
//   | ++----+   
//   +-++    |  
//     |     |  
//   +-+--+  |   
//   | +--+--+  
//   +----+    Copyright (c) 2008 Code Red Technologies Ltd. 
//
// cr_boardsetup.c - Board setup routine for Code Red RDB1768 Development Board
//
// Software License Agreement
// 
// The software is owned by Code Red Technologies and/or its suppliers, and is 
// protected under applicable copyright laws.  All rights are reserved.  Any 
// use in violation of the foregoing restrictions may subject the user to criminal 
// sanctions under applicable laws, as well as to civil liability for the breach 
// of the terms and conditions of this license.
// 
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// LMI SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
// CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
// 
//*****************************************************************************
#include "NXP/LPC17xx/LPC17xx.h"
#include "NXP/LPC17xx/type.h"
#include "NXP/LPC17xx/target.h"
#include "it.h"
#include "NXP/LPC17xx/nvic.h"
#include "NXP/LPC17xx/systick.h"
#include "i2s.h"
#include "dma.h"

#include "ethmac.h"

extern volatile BYTE *I2STXBuffer, *I2SRXBuffer;
extern volatile DWORD I2SReadLength;
extern volatile DWORD I2SWriteLength;
extern volatile DWORD I2SRXDone, I2STXDone;
extern volatile DWORD I2SDMA0Done, I2SDMA1Done;

#define portCHAR		char
#define portFLOAT		float
#define portDOUBLE		double
#define portLONG		long
#define portSHORT		short
#define portSTACK_TYPE	unsigned portLONG
#define portBASE_TYPE	long
#if( configUSE_16_BIT_TICKS == 1 )
	typedef unsigned portSHORT portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffff
#else
	typedef unsigned portLONG portTickType;
	#define portMAX_DELAY ( portTickType ) 0xffffffff
#endif
	
/* Constants required to manipulate the NVIC. */
#define portNVIC_SYSTICK_CTRL		( ( volatile unsigned portLONG *) 0xe000e010 )
#define portNVIC_SYSTICK_LOAD		( ( volatile unsigned portLONG *) 0xe000e014 )
#define portNVIC_INT_CTRL			( ( volatile unsigned portLONG *) 0xe000ed04 )
#define portNVIC_SYSPRI2			( ( volatile unsigned portLONG *) 0xe000ed20 )
#define portNVIC_SYSTICK_CLK		0x00000004
#define portNVIC_SYSTICK_INT		0x00000002
#define portNVIC_SYSTICK_ENABLE		0x00000001
#define portNVIC_PENDSVSET			0x10000000
#define portNVIC_PENDSV_PRI			( ( ( unsigned portLONG ) configKERNEL_INTERRUPT_PRIORITY ) << 16 )
#define portNVIC_SYSTICK_PRI		( ( ( unsigned portLONG ) configKERNEL_INTERRUPT_PRIORITY ) << 24 )
#define configCPU_CLOCK_HZ			( ( unsigned portLONG ) 50000000 )
#define configTICK_RATE_HZ			( ( portTickType ) 100 )
/*
 * Setup the systick timer to generate the tick interrupts at the required
 * frequency.
 */
void prvSetupTimerInterrupt( void )
{
	/* Configure SysTick to interrupt at the requested rate. */
	*(portNVIC_SYSTICK_LOAD) = ( configCPU_CLOCK_HZ / configTICK_RATE_HZ ) - 1UL;
	*(portNVIC_SYSTICK_CTRL) = portNVIC_SYSTICK_CLK | portNVIC_SYSTICK_INT | portNVIC_SYSTICK_ENABLE;
}

void cr_boardsetup (void)
{

  TargetResetInit();

  NVIC_DeInit();
  NVIC_SCBDeInit();

#if __IRAM
  //Added new RAM type.
  NVIC_SetVectorTable(NVIC_VectTab_RAM_AHB, 0x0); 
#else
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0); 
#endif

  /* Configure the NVIC Preemption Priority Bits */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  /* P1.27 -> CLKOUT */
  PINSEL3 |= 0x00400000;

  /* CLKOUT == USB_CLK */
//  CLKSRCSEL |= 0x80;
  /* CLKOUT == Main OSC. */
  CLKSRCSEL |= 0x40;

  /* P3.26 -> STCLK */
  PINSEL7 |= 0x00100000;

  (*(volatile unsigned long *)(SCB_BASE_ADDR + 0x1FC)) = 120000;

  /* Select CCLK as SysTick clock source */
  SysTick_CLKSourceConfig(SysTick_CLKSource_STCLK);

  /* SysTick event each 10 ms with input clock equal to 12MHz */
  SysTick_SetReload(120000);

  /* Enable SysTick interrupt */
  SysTick_ITConfig(ENABLE);

  /* Enable the SysTick Counter */
  SysTick_CounterCmd(SysTick_Counter_Enable);

  FIO1DIR = 1 << 25;                    // P1.25 defined as Output

  prvSetupTimerInterrupt();

}

