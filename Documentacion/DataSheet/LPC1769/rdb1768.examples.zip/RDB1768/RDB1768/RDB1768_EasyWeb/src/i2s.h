/*****************************************************************************
 *   i2s.h:  Header file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2008, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2008.09.18  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#ifndef __I2S_H 
#define __I2S_H

#define I2S_DMA_ENABLED		1

#define I2S_BUFSIZE			0x200
#define RXFIFO_EMPTY		0
#define TXFIFO_FULL			8

typedef struct {
  DWORD pin_4;
  DWORD clksel;
  DWORD dircntrl;
} I2S_CLK_SELECT_SETUP_T;

typedef struct {
  DWORD y_divider;
  DWORD x_divider;
  DWORD bitrate;
} I2S_CLK_RATE_SETUP_T;

typedef struct {
  DWORD wordwidth;
  DWORD mono;
  DWORD master;
  DWORD ws_halfperiod;
  DWORD mute;
} I2S_AUDIO_SETUP_T;

void I2SIrqHandler(void);
void I2SStart(void);
void I2SStop(void);
void I2SInit(void);
void I2SClkSelect(DWORD tx, I2S_CLK_SELECT_SETUP_T* clk_select_setup);
void I2SClkRateSetup(DWORD tx, I2S_CLK_RATE_SETUP_T* clk_rate_setup);
void I2SAudioSetup(DWORD dao, I2S_AUDIO_SETUP_T* audio_setup);

#endif /* end __I2S_H */
/****************************************************************************
**                            End Of File
*****************************************************************************/
