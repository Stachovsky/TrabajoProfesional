Code Red Technologies RDB1768 Board - USB Stack and Examples
============================================================

The USB stack and associated examples provided with RDB1768 board are
based on the open source LPCUSB stack, originally written for the NXP
LPC214x microcontrollers.

For more details, please see the readme.txt file contained in the 
RDB1768 usbstack project.

 