pwm
=====================
This project demonstrates how to set up and use the pwms on the
LPC1114. It configures two timers to generate PWM outputs. The
results can be seen on Timer 32 #1 Match 0 (PIO1_1) and Timer 16
1 Match 1 (PIO1_10). Both PWMs run at 48 kHz.
