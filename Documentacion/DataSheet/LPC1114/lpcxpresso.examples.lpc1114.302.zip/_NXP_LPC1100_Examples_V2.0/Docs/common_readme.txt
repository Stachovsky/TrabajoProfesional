LPCXpresso examples common files
================================
Welcome to the LPCXpresso examples common files project. This project
does not build. It is used together with the template project to
create other projects.

See template_readme.txt in the template project for a complete
explanation.
