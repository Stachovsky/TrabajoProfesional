LPCXpresso1102_systick
======================
This project contains a LED flashing Systick example for the LPCXpresso
board mounted with an LPC1102 Cortex-M0 part.

When downloaded to the board and executed, LED2 will be illuminated.
The state of LED2 will toggle every 2 seconds, timed using the Cortex-M0's
built in Systick timer.

The project makes use of code from the following library project:
- CMSISv1p30_LPC1102 : for CMSIS 1.30 files relevant to LPC1102

This library project must exist in the same workspace in order
for the project to successfully build.

~~~~~~~~~~~~

Note that this example uses the file "lpc1102_isp.c" to set up a pin to
act as an ISP pin at reset. See the comments in that file, along with
NXP's AN11015 "Adding ISP to LPC1102 systems" document for more 
information.