#ifndef FONTS_H_
#define FONTS_H_

#define FAST_FONT_INDEX

#endif
