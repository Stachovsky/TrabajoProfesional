
BASEBOARD API

Las siguientes funciones estan disponibles para utilizar algunos 
perifericos del BaseBoard de manera rápida y sencilla.

Importante: Se debe linkear el proyecto a esta biblioteca e incluir:
#include "baseboard.h"

=====================================================================
Rutina de inicialización
=====================================================================
initBaseBoard();

Se la debe llamar al comienzo de la aplicación. 
Esta tarea configura los pines y enciende y configura los perifericos necesarios.

=====================================================================
Manejo de salidas
=====================================================================

--------------------------------------------------
 Leds RGB
--------------------------------------------------
RGB_Off();				Apaga todos los leds
RGB_blueLedOn();		Prende el led azul
RGB_redLedOn();			Prende el led rojo
RGB_greenLedOn();		Prende el led verde
RGB_blueLedOff();		Prende el led azul
RGB_redLedOff();			Prende el led rojo
RGB_greenLedOff();		Prende el led verde

--------------------------------------------------
Display 7 segmentos
--------------------------------------------------
led7segDisplay(i);		Se le debe pasar como parametro un numero del 0 al 9

--------------------------------------------------	
Barrales de leds
--------------------------------------------------	
redLedBarSet(n);		El valor binario pasado como parametro se representa en los leds
greenLedBarSet(n);		El valor binario pasado como parametro se representa en los leds
			
--------------------------------------------------
Oled Gráfico de 96x64
--------------------------------------------------			
oled_clearScreen(OLED_COLOR_WHITE);
oled_putString(x,y, "Hola!", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
oled_putNumber(x,y,,OLED_COLOR_BLACK,OLED_COLOR_WHITE);

Si se quiere usar como terminal, con lineas automaticas usar:
screenLogNumber(n);
screenLogText("texto");

--------------------------------------------------
Manejo de la UART (hardcodeada a LPC_UART3 115200-8-N-1)
--------------------------------------------------
UART_SendString("hola:");
UART_SendNumber(i);

=====================================================================
Manejo de entradas
=====================================================================
readPote()		Lee el valor del potenciometro en 12 bits
light_read()	Lee el valor de la luz


Author: Alan Kharsansky <akharsa@gmail.com>