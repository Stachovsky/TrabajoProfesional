
#include "LPC17xx.h"
#include "acc.h"
#include "led7seg.h"
#include "oled.h"
#include "potentiometer.h"
#include "uart.h"
#include "RGBLed.h"
#include "light.h"
#include "pca9532.h"
#include "xbee.h"
#include "screenlog.h"

void initBaseBoard();
