#ifndef __POTE__H
#define __POTE__H

uint32_t readPote();

#endif
