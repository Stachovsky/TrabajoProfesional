#ifndef __UART_H
#define __UART_H

void UART_SendString(char * msg);
void UART_SendNumber(int n);

#endif
