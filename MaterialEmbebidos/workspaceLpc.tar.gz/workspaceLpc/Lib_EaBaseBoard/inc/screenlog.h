/*
 * screenlog.h
 *
 *  Created on: 14/09/2011
 *      Author: Alan
 */

#ifndef SCREENLOG_H_
#define SCREENLOG_H_

void screenLogText(char * msg);
void screenLogNumber(int n);

#endif /* SCREENLOG_H_ */
