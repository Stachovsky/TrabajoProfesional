#include "lpc17xx_pinsel.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_timer.h"

/*********************************************************************//**
 * @brief 		Transmitir datos I2C
 * @param[in]	addr			Dirección esclavo
 * @param[in]	buf				datos a enviar
 * @param[in]	len				longitud datos a enviar
 * @return 		0 SUCCESS or -1 ERROR
 *
 **********************************************************************/

static int I2CWrite(uint8_t addr, uint8_t* buf, uint32_t len)
{
	I2C_M_SETUP_Type txsetup;

	txsetup.sl_addr7bit = addr;
	txsetup.tx_data = buf;
	txsetup.tx_length = len;
	txsetup.rx_data = NULL;
	txsetup.rx_length = 0;
	txsetup.retransmissions_max = 3;

	if (I2C_MasterTransferData(LPC_I2C2, &txsetup, I2C_TRANSFER_POLLING) == SUCCESS){
		return (0);
	} else {
		return (-1);
	}
}

int main (void) {

    while (1) {

    }


}
