#include "lpc17xx_pinsel.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_timer.h"

static int I2CWrite(uint8_t addr, uint8_t* buf, uint32_t len)
{
	I2C_M_SETUP_Type txsetup;

	txsetup.sl_addr7bit = addr;
	txsetup.tx_data = buf;
	txsetup.tx_length = len;
	txsetup.rx_data = NULL;
	txsetup.rx_length = 0;
	txsetup.retransmissions_max = 3;

	if (I2C_MasterTransferData(LPC_I2C2, &txsetup, I2C_TRANSFER_POLLING) == SUCCESS){
		return (0);
	} else {
		return (-1);
	}
}

int main (void) {

	PINSEL_CFG_Type PinCfg;
	uint8_t data [5];
	uint8_t control_reg = 0;
	uint8_t address_PCA9532 = 0b1100000;

	/* Initialize I2C2 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);

    while (1) {
    	control_reg = 0b00010110;
    	data[0]=control_reg;
    	data[1]=0b01010101;
    	data[2]=0b01010101;
    	data[3]=0b01010101;
    	data[4]=0b01010101;

    	uint32_t delay = 100;

    	I2CWrite(address_PCA9532, data, 5);

        Timer0_Wait(delay);

    	data[1]=0b00000000;
    	data[2]=0b01010101;
    	data[3]=0b00000000;
    	data[4]=0b01010101;

    	I2CWrite(address_PCA9532, data, 5);

        Timer0_Wait(delay);

    	data[1]=0b01010101;
    	data[2]=0b00000000;
    	data[3]=0b01010101;
    	data[4]=0b00000000;

    	I2CWrite(address_PCA9532, data, 5);

    	Timer0_Wait(delay);
    }


}
