blinky
=====================
This project contains a LED flashing example for the LPCXpresso board.

When downloaded to the board and executed, LED2 will flash at regular
intervals.
