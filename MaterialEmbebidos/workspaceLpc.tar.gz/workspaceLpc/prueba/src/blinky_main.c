
#include <stdint.h>
#include "LPC11xx.h"

/* Main Program */

int main (void)
{
	int j;
	for(j = 0;j < 8; j++){
		LPC_GPIO0->DIR |= (1<<j);
		LPC_GPIO1->DIR |= (1<<j);
		LPC_GPIO2->DIR |= (1<<j);
		LPC_GPIO3->DIR |= (1<<j);
	}

  while (1)                                /* Loop forever */
  {
	  int i;

	  for(i=0; i < 8; i++){
		  LPC_GPIO0->MASKED_ACCESS[(1<<i)] = (1<<i);
		  LPC_GPIO1->MASKED_ACCESS[(1<<i)] = (1<<i);
		  LPC_GPIO2->MASKED_ACCESS[(1<<i)] = (1<<i);
		  LPC_GPIO3->MASKED_ACCESS[(1<<i)] = (1<<i);
	  }
		  //LPC_GPIO0->DATA |= (0<<i);

	  for(i=0; i < 4000000;i++);

	  for(i=0; i < 8; i++){
		  LPC_GPIO0->MASKED_ACCESS[(1<<i)] = (0<<i);
		  LPC_GPIO1->MASKED_ACCESS[(1<<i)] = (0<<i);
		  LPC_GPIO2->MASKED_ACCESS[(1<<i)] = (0<<i);
		  LPC_GPIO3->MASKED_ACCESS[(1<<i)] = (0<<i);
	  }
		  //LPC_GPIO0->DATA |= (1<<i);

	  for(i=0; i < 4000000;i++);

  }
}

