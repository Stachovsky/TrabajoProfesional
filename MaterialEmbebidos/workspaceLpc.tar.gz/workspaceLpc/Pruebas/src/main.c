/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC11xx.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here

// TODO: insert other definitions and declarations here

int i;
int estado = 0;

//--------------------------------------------------
//Interupcion SysTick
//--------------------------------------------------
void SysTick_Handler(void){

	if(estado){
		LPC_GPIO0->DATA |= (1 << 7);
	}else{
		LPC_GPIO0->DATA &= ~(1 << 7);
	}

	estado = (estado == 1)?0:1;
}

//--------------------------------------------------
//Interupcion I2C
//--------------------------------------------------
void I2C_IRQHandler(void){
	LPC_GPIO0->DATA |= (1 << 7);
}

//--------------------------------------------------
//--------------------------------------------------

int main(void) {

	SysTick_Config(SystemCoreClock/4);

	// Configuro las GPIO como salidas
	LPC_GPIO0->DIR |= (1 << 7);

	//se inicia en 0
	LPC_GPIO0->DATA &= ~(1 << 7);

	//--------------------------------
	// i2c
	//--------------------------------

	  LPC_SYSCON->PRESETCTRL |= (0x1<<1);

	  LPC_SYSCON->SYSAHBCLKCTRL |= (1<<5);
	  LPC_IOCON->PIO0_4 &= ~0x3F;	/*  I2C I/O config */
	  LPC_IOCON->PIO0_4 |= 0x01;		/* I2C SCL */
	  LPC_IOCON->PIO0_5 &= ~0x3F;
	  LPC_IOCON->PIO0_5 |= 0x01;		/* I2C SDA */

	  LPC_I2C->SCLL   = 0x00000180;
	  LPC_I2C->SCLH   = 0x00000180;

	  LPC_I2C->ADR0 = 0x01010101;

	  LPC_I2C->CONSET = (0x1<<6);

	  /* Enable the I2C Interrupt */
  	  NVIC_EnableIRQ(I2C_IRQn);


	//--------------------------------

	NVIC_EnableIRQ(SysTick_IRQn);

	  while (1)                                /* Loop forever */
	  {

	  }

	return 0 ;
}
