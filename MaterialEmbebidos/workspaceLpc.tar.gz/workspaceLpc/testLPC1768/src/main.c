/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "include/lpc17xx_gpio.h"
#include "include/lpc17xx_pinsel.h"
#include "include/lpc17xx_uart.h"
#endif

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

// TODO: insert other include files here

// TODO: insert other definitions and declarations here

void SysTick_Handler(void){


}

void delay(){
	int i = 0;
	for(i=0; i < 2000000; i++);
}



int main(void) {

	SysTick_Config(1000);

	NVIC_EnableIRQ(SysTick_IRQn);

	GPIO_SetDir(0, (1 << 26), 1);
	GPIO_SetDir(2, (1 << 1), 1);
	GPIO_SetDir(2, (1 << 0), 1);

	while(1) {

		GPIO_SetValue(0,(1 << 26));
		delay();
		GPIO_ClearValue(0,(1 << 26));

		GPIO_SetValue(2,(1 << 0));
		delay();
		GPIO_ClearValue(2,(1 << 0));

		GPIO_SetValue(2,(1 << 1));
		delay();
		GPIO_ClearValue(2,(1 << 1));

	}

	return 0 ;
}
