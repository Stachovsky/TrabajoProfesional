/*
 * driver_config.h
 *
 *  Created on: Aug 31, 2010
 *      Author: nxp28548
 */

#ifndef DRIVER_CONFIG_H_
#define DRIVER_CONFIG_H

#include <LPC11xx.h>

#define CONFIG_ENABLE_DRIVER_CRP						1
#define CONFIG_CRP_SETTING_NO_CRP						1

#define CONFIG_ENABLE_DRIVER_TIMER16					1

#define CONFIG_ENABLE_DRIVER_GPIO						1

#define CONFIG_ENABLE_DRIVER_WDT						1
#define CONFIG_WDT_WATCHDOG_RESET						1
#define WDT_FEED_VALUE									(8000*5)

/* DRIVER_CONFIG_H_ */
#endif
