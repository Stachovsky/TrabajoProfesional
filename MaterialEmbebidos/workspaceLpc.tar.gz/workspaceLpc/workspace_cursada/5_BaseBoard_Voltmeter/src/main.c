/*
===============================================================================
 Name        : main.c
 Author      : Jorge Graña
 Version     : 3.0
 Copyright   : Copyright (C)
 Description : Implementacion de un voltimetro con el LPC1768,
				 para practicar aritmetica en punto fijo.
===============================================================================
*/


#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "baseboard.h"
// reemplaza y contiene a :
#include "lpc17xx_pinsel.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_gpio.h"

#include "lpc17xx_uart.h"

#include "lpc17xx_i2c.h"
#include "lpc17xx_ssp.h"
#include "oled.h"

//==============================================================================================
//Configuracion del hard y soft del voltimetro

//TODO: colocar el Jumper J57 para agregar offset

//#define VinRangoPosi 1 		// Rango : 0v < Vin < 3,3v
#define VinRangoMixto 1			// Rango :-5v < Vin < 8,25v

//#define MEDIA_ARITME 1 		// media aritmetica (revisar)
#define MEDIA_ARITME 0			// media estadistica


//#define TRIMPOT 1 			// seleccion del canal A/D
#define BNC 1

#define OLED 1 			// seleccion salida por OLED
//#define UART 1		// seleccion salida por UART


//==============================================================================================
// Defino tipo de datos utilizados

static const uint32_t Fsample = 200000;     	// Frec de muestreo

static const uint32_t ADMAX = 4096;				//AD de 12 bits !!!

// Conversor AD 10bit: mejor caso 3,3v / 1023 = 0,0032v = 3,2mV
// Conversor AD 12bit: mejor caso 3,3v / 4095 = 0,0080v = 0,8mV

//TODO typedef uint32_t fxp32_escalaAD;
typedef int32_t fxp32_escalaAD;

// La Vmedia: tenemos 12bit ad + 10bit = 22bits
typedef int32_t fxp32_escalaMediaN;

static const uint32_t Nbit = 10;     			// cant bit de expansion del formato base

#if MEDIA_ARITME
static const uint32_t Nbuffer = 100; 			// cantidad de muestras almacenadas para media aritmeica
#endif

//==============================================================================================
//string...

const uint8_t MessageWelcome[]={"\n\rVoltimetro con LPC1768\n\r"};
const uint8_t MessageTrimpot[]={"\n\rEntrada TRIMPOT\n\r"};
const uint8_t MessageBNC[]={"\n\rEntrada BNC\n\r"};
const uint8_t Message3v3[]={"\n\rVin : 0v a 3v3\n\r"};
const uint8_t Message8v25[]={"\n\rVin : -5v a 8v25\n\r"};
const uint8_t MessageJ57[]={"\n\rColocar J57\n\r"};
const uint8_t MessageCal[]={"\n\rCalibrando...\n\r"};
const uint8_t MessageValues[]={"\n\rADinst\tVinst\t\tVmax\t\tVmin\t\tVmedia\t\tVefic\t\tn\tError\n\r"};

const uint8_t MessageClrScr[]={"\x1B[2J"};
const uint8_t MessageCursorON[]={"\x1B[?25h"};
const uint8_t MessageCursorOFF[]={"\x1B[?25l"};


//==============================================================================================
// Aritmetica punto fijo: Constantes

static const uint32_t Ndig = 1000;
//static const uint32_t EscalaNumeN = 100000;

// Rango : 0v < Vin < 3,3v
#if VinRangoPosi
	static const uint32_t EscalaNume = 220;  		// Vad * 100 / 31
	static const uint32_t EscalaDeno = 273;
#endif

// Rango : -5v < Vin < 8,25v
#if VinRangoMixto
	static const uint32_t EscalaNume = 880;  		// Vad * 400 / 31
	static const uint32_t EscalaDeno = 273;
#endif


static const uint32_t FacFormaNume = 111;   		// Factor Forma senoidal=1,11
static const uint32_t FacFormaDeno = 100;

//==============================================================================================
// Struct que contiene los datos del Voltimetro

typedef struct
	{
	fxp32_escalaAD ADvalor ;						// valor instantaneo AD
    fxp32_escalaAD Vvalor ;						// variable intermedia temporal usada para display
    fxp32_escalaMediaN ADmedia ;					// valor promedio DC
    fxp32_escalaMediaN ADmediaRecAC ;			// valor promedio AC
    fxp32_escalaMediaN ADeficazAC ;				// valor promedio AC  efic
    fxp32_escalaAD ADvalorAConly ;				// valor instantaneo solo AC o sea Vmedia=0v
    fxp32_escalaAD ADvalorAConlyRec ;			// valor instantaneo solo AC rectificado
	#if VinRangoMixto
		fxp32_escalaAD ADoffset;
	#endif
	fxp32_escalaAD ADmediaDisplay ;						// valor promedio AD
    fxp32_escalaAD ADmax ;
    fxp32_escalaAD ADmin ; //= ADMAX;

    uint32_t NadDisplay;						// cant de conversiones del AD
     uint8_t Error;								// 0= no existio error

	#if MEDIA_ARITME
		uint32_t b;												// indice array
		fxp32_escalaAD ADCbuffer[100];// Nbuffer];						// buffer almacena AD para media aritmetica
	#endif

	} typeVoltimetro;


	// creo una estructura para almacenar los datos que surguen de procesar los valores del AD
	typeVoltimetro Volt;
	typeVoltimetro * pVolt = & Volt;


//------------------------------------------------------

// ojo definida en Oled.c intToString
static void MyIntToString(fxp32_escalaAD , uint8_t* , uint32_t , uint32_t );
static void QmnToString(fxp32_escalaAD , uint32_t , uint32_t nLen, uint8_t* , uint32_t );

fxp32_escalaAD ADtoVolt(fxp32_escalaAD , fxp32_escalaAD , fxp32_escalaAD );

static void init_ssp(void);
static void init_i2c(void);

void InitVoltimetro(void);
void InitVolt(typeVoltimetro *);
void ProcesaValor( typeVoltimetro * );
void TransmitValor(typeVoltimetro * );
void MostrarValor(typeVoltimetro * );	
	

//==============================================================================================
int main(void) {

	uint32_t i;

	InitVoltimetro();    	//initBaseBoard(); esta forzado el canal 0 del A/D

	// Dejarlo prendido para poder usar el OLED! comparten el pin
	//RGB_greenLedOn();

	InitVolt(pVolt);   //inicializo la struct

	while(1)
	{
//------acopio informacion---------------------------------
		for (i=0;i<pVolt->NadDisplay;i++)
			{		
		
			//------acopio informacion---------------------------------

			//----- Start conversion
			ADC_StartCmd(LPC_ADC,ADC_START_NOW);
	
			#if TRIMPOT
				//Wait conversion complete
				while (!(ADC_ChannelGetStatus(LPC_ADC,ADC_CHANNEL_0,ADC_DATA_DONE)));
				pVolt->ADvalor = ADC_ChannelGetData(LPC_ADC,ADC_CHANNEL_0);
			#endif

			#if BNC
				//Wait conversion complete
				while (!(ADC_ChannelGetStatus(LPC_ADC,ADC_CHANNEL_5,ADC_DATA_DONE)));
				pVolt->ADvalor = ADC_ChannelGetData(LPC_ADC,ADC_CHANNEL_5);
				#if VinRangoMixto
						pVolt->ADvalor -=pVolt->ADoffset;
				#endif
			#endif

			ProcesaValor( pVolt);

			}

		//------muestra la  informacion---------------------------------

		#if UART
			TransmitValor(pVolt);
		#endif

		#if OLED
			MostrarValor(pVolt);
		#endif

		InitVolt(pVolt);   //inicializo la struct

	}

	return 0 ;
	
}
//==============================================================================================


//==============================================================================================
// Funcion que convierte de fxp32_escalaAD a String, su implementacion no es relevante para el ejemplo
static void MyIntToString(fxp32_escalaAD value, uint8_t* pBuf, uint32_t len, uint32_t base)
{
    static const char* pAscii = "0123456789abcdefghijklmnopqrstuvwxyz";
    int pos = 0;
    int tmpValue = value;

    // the buffer must not be null and at least have a length of 2 to handle one
    // digit and null-terminator
    if (pBuf == 0 || len < 2)
    {
        return;
    }

    // a valid base cannot be less than 2 or larger than 36
    // a base value of 2 means binary representation. A value of 1 would mean only zeros
    // a base larger than 36 can only be used if a larger alphabet were used.
    if (base < 2 || base > 36)
    {
        return;
    }

    // negative value
    if (value < 0)
    {
        tmpValue = -tmpValue;
        value    = -value;
        pBuf[pos++] = '-';
    }

    // calculate the required length of the buffer
    do {
        pos++;
        tmpValue /= base;
    } while(tmpValue > 0);



    if (pos > len)
    {
        // the len parameter is invalid.
        return;
    }

    // limpio los restos del valor anterior
    while (len>=pos+1)

    	pBuf[len--] = NULL;

    //finalizo el string
    pBuf[pos] = '\0';

    do {
        pBuf[--pos] = pAscii[value % base];
        value /= base;
    } while(value > 0);

    return;
}
//==============================================================================================



/*==============================================================================================
* QmnToString : convierte de Qmn a string
*
* uint32_t value : valor numerico en formato Qmn
* uint32_t mLen : cantidad de digitos enteros
* uint32_t nLen : cantidad de digitos francionarios
* uint8_t* pBuf : string de salida
* uint32_t base : base en la que se expresa el string
*
/==============================================================================================*/
static void QmnToString(fxp32_escalaAD value, uint32_t mLen, uint32_t nLen, uint8_t* pBuf, uint32_t base)
{
    static const char* pAscii = "0123456789abcdefghijklmnopqrstuvwxyz";
    int pos = 0;
    fxp32_escalaAD tmpValue = value;


    // the buffer must not be null and at least have a length of 2 to handle one
    // digit and null-terminator
    if (pBuf == NULL || mLen < 2 || nLen < 2)
    {
        return;
    }

    // a valid base cannot be less than 2 or larger than 36
    // a base value of 2 means binary representation. A value of 1 would mean only zeros
    // a base larger than 36 can only be used if a larger alphabet were used.
    if (base < 2 || base > 36)
    {
        return;
    }

    // negative value
    if (value < 0)
    {
        value    = -value;
    //    pBuf[pos++] = '-';
    }

    pos += mLen +  nLen;

    pBuf[pos] = '\0';								// fin del string

    do {											// parte fraccionaria
        pBuf[--pos] = pAscii[value % base];
        value /= base;
    } while(pos > mLen);

    pBuf[--pos] = ',';								// separador

	pBuf[--pos] = pAscii[value % base];
    value /= base;

    do {											// parte entera
    	if ( value==0 )
    		pBuf[--pos] = ' ';
    	else
    		pBuf[--pos] = pAscii[value % base];
        value /= base;
    } while(pos > 0);

    if (tmpValue < 0)
      {
//          tmpValue = -tmpValue;
 //         value    = -value;
          pBuf[pos] = '-';
      }
    return;
}
//==============================================================================================



//==============================================================================================
fxp32_escalaAD ADtoVolt(fxp32_escalaAD ADvalor, fxp32_escalaAD EscalaNume, fxp32_escalaAD EscalaDeno)
	{
	fxp32_escalaAD Vvalor;

    Vvalor=(ADvalor*EscalaNume)/EscalaDeno;

    return(Vvalor);
	}
//==============================================================================================



//==============================================================================================
static void init_ssp(void)
{
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);

}

static void init_i2c(void)
{
	PINSEL_CFG_Type PinCfg;

	/* Initialize I2C2 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);
}
//==============================================================================================




//==============================================================================================
// Inicializacion de los perifericos y saludo inicial
void InitVoltimetro(void)
{

//--------- Display Oled --------------------------------------------------------
	 init_i2c();
	 init_ssp();

	 oled_init();

//--------- UART--------------------------------------------------------
	// Declaramos estructuras para usar en la configuracion
	UART_CFG_Type UARTConfigStruct;
	PINSEL_CFG_Type PinCfg;

	// Configuracion de los pines de Rx y Tx
	PinCfg.Funcnum = PINSEL_FUNC_2;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_NORMAL;//PULLUP;
	PinCfg.Pinnum = PINSEL_PIN_0;
	PinCfg.Portnum = PINSEL_PORT_0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = PINSEL_PIN_1;
	PINSEL_ConfigPin(&PinCfg);


	// Configuramos la UART
	UARTConfigStruct.Baud_rate = 115200;
	UARTConfigStruct.Databits = UART_DATABIT_8;
	UARTConfigStruct.Parity = UART_PARITY_NONE;
	UARTConfigStruct.Stopbits = UART_STOPBIT_1;

	// Inicializamos la UART
	UART_Init(LPC_UART3, &UARTConfigStruct);
	UART_TxCmd(LPC_UART3, ENABLE);


//---------A/D--------------------------------------------------------
#if TRIMPOT
	// Configuracion del pin GPIO0.23 como ADC. Corresponde a AD0
	PinCfg.Funcnum = PINSEL_FUNC_1;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_NORMAL;//PULLUP;
	PinCfg.Pinnum = PINSEL_PIN_23;		//Trimpot
	PinCfg.Portnum = PINSEL_PORT_0;		//Trimpot
#endif

#if BNC
	// Configuracion del pin GPIO1.31 como ADC. Corresponde a AD5
	PinCfg.Funcnum = PINSEL_FUNC_3;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	PinCfg.Pinnum = PINSEL_PIN_31;		//BNC
	PinCfg.Portnum = PINSEL_PORT_1;		//BNC
#endif

	PINSEL_ConfigPin(&PinCfg);

	// Inicializamos el Conversor A/D primero
	ADC_Init(LPC_ADC, Fsample);


	#if TRIMPOT
	ADC_IntConfig(LPC_ADC,ADC_ADINTEN0,DISABLE);
	ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_0,ENABLE);  				//Trimpot
	#endif

	#if BNC
	ADC_IntConfig(LPC_ADC,ADC_ADINTEN5,DISABLE);
	ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_5,ENABLE);  				//BNC
	#endif

//-------------------------------------------------------------------
	// Enviamos el mensajes de bienvenida

#if TRIMPOT
	UART_Send(LPC_UART3, MessageTrimpot, sizeof(MessageTrimpot), BLOCKING);
#endif

#if BNC
	UART_Send(LPC_UART3, MessageBNC, sizeof(MessageBNC), BLOCKING);
#endif


#if VinRangoPosi
UART_Send(LPC_UART3, Message3v3, sizeof(Message3v3), BLOCKING);

#endif


//TODO:supongo que la entrada esta a masa y mido la Voffset
#if VinRangoMixto
	UART_Send(LPC_UART3, Message8v25, sizeof(Message8v25), BLOCKING);
	UART_Send(LPC_UART3, MessageJ57, sizeof(MessageJ57), BLOCKING);
//	UART_Send(LPC_UART3, MessageCal, sizeof(MessageCal), BLOCKING);

#endif



	#if UART
		UART_Send(LPC_UART3, MessageClrScr, sizeof(MessageClrScr), BLOCKING);
		UART_Send(LPC_UART3, MessageCursorON, sizeof(MessageCursorON), BLOCKING);
		UART_Send(LPC_UART3, MessageWelcome, sizeof(MessageWelcome), BLOCKING);
	#endif

	#if OLED
	//	oled_clearScreen(OLED_COLOR_WHITE);
		oled_clearScreen(OLED_COLOR_BLACK);
		    oled_putString(1,1,  (uint8_t*)"AD   =", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,9,  (uint8_t*)"V    =", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,17, (uint8_t*)"Vmax =", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,25, (uint8_t*)"Vmin =", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,33, (uint8_t*)"Vprom=", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,41, (uint8_t*)"Vefic=", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
		    oled_putString(1,49, (uint8_t*)"n    =", OLED_COLOR_WHITE, OLED_COLOR_BLACK);
	#endif

}
//==============================================================================================



//==============================================================================================
//-------Reinicia algunas variables
void InitVolt(typeVoltimetro * pVolt)
{
	// cada NadDisplay muestras del A/D se muestra la informacion
	pVolt->NadDisplay=20000;

	// inicializo el indice del array usado para hacer media aritmetica

	#if MEDIA_ARITME
		pVolt->b = 0;     				// inicializo el indice del array para media aritmetica
	#endif


	#if VinRangoMixto

		// coloque la entrada BNC a GND y lei el valor que entregaba el A/D :S
		pVolt->ADoffset = 1608;

		pVolt->ADmax -=pVolt->ADoffset;
		pVolt->ADmin =ADMAX-pVolt->ADoffset;
		//pVolt->ADmin -=pVolt->ADoffset;	

		#else
		pVolt->ADmax=0;
		pVolt->ADmin=ADMAX;
	#endif
}
//==============================================================================================


//==============================================================================================
void ProcesaValor(typeVoltimetro * pVolt)
{
//------Almacena el maximo y el minimo ---------------------
				if( pVolt->ADmax < pVolt->ADvalor )		pVolt->ADmax = pVolt->ADvalor;
				if( pVolt->ADmin > pVolt->ADvalor ) 	pVolt->ADmin = pVolt->ADvalor;

		//------ Calculo valor Medio ---------------------------------
				#if MEDIA_ARITME
						// almaceno datos en array ENORME para la media aritmetica
						if ( (pVolt->b) <= Nbuffer )
						pVolt->ADCbuffer[pVolt->b++] = pVolt->ADvalor;

				#else
						// calculo de media estadistica
						// Vmedia =  ( ( n - 1 ) * Vmedia + Vinstan ) / n

						//Vmedia = 4096 * Vinstan
						// para no perder presicion en la media FORMATO EXTENDIDO

						// Vmedia =  Vmedia - (Vmedia / 4096 ) +  4096 *( Vinstan / 4096)

						pVolt->ADmedia -= pVolt->ADmedia >> Nbit;						// le esto 1/4096 avas partes
						pVolt->ADmedia += pVolt->ADvalor;								// le sumo 1/4096 avas partes de la nueva muestra
				#endif

	//-------- Le quita la componente de DC a la se�al, dejando solo AC

				pVolt->ADvalorAConly = pVolt->ADvalor - (pVolt->ADmedia >> Nbit);

   	//--------- Calcula el modulo de la componente de alterna, rectifica!!!
				if (pVolt->ADvalorAConly < 0 )
					pVolt->ADvalorAConlyRec= -pVolt->ADvalorAConly;
				else
					pVolt->ADvalorAConlyRec= pVolt->ADvalorAConly;

	//--------- Acumula la media del valor rectificado
				pVolt->ADmediaRecAC -= pVolt->ADmediaRecAC >> Nbit;			// le resto 1/4096 avas partes
				pVolt->ADmediaRecAC += pVolt->ADvalorAConlyRec;				// le sumo 1/4096 avas partes de la nueva muestra

	//-----------Calcula la Veficaz para senoidal, a travez del factor de forma
				pVolt->ADeficazAC = pVolt->ADmediaRecAC * FacFormaNume / FacFormaDeno;

	//TODO:		Ejercicio :
	//			CAMBIAR EL CODIGO PARA COVERTIR ESTE VOLTIMETRO EN TRUE RMS

	}
//==============================================================================================


//==============================================================================================
void TransmitValor(typeVoltimetro * pVolt)
{
	uint8_t buf[11];
	fxp32_escalaAD Vvalor;									// auxiliar temporal
	fxp32_escalaMediaN ADmediaDisplay; 						// auxiliar temporal

//
//	MyIntToString(pVolt->ADvalor, buf, 10, 10);
//	UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);  		//strlen
//	UART_SendByte(LPC_UART3,'\t');
//
//	Vvalor=ADtoVolt(pVolt->ADvalor, EscalaNume, EscalaDeno);
//	QmnToString(Vvalor, 3, 3, buf, 10);
//	UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//	UART_Send(LPC_UART3, " v", sizeof(" v"), BLOCKING);
//	UART_SendByte(LPC_UART3,'\t');
//
//	Vvalor=ADtoVolt(pVolt->ADmax, EscalaNume, EscalaDeno);
//    QmnToString(Vvalor, 3, 3, buf, 10);
//	UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//	UART_Send(LPC_UART3, " v", sizeof(" v"), BLOCKING);
//	UART_SendByte(LPC_UART3,'\t');
//
//	Vvalor=ADtoVolt(pVolt->ADmin, EscalaNume, EscalaDeno);
//	QmnToString(Vvalor, 3, 3, buf, 10);
//	UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//	UART_Send(LPC_UART3, " v", sizeof(" v"), BLOCKING);
//	UART_SendByte(LPC_UART3,'\t');
//
//	#if MEDIA_ARITME
//  		// recien ahora con todos los datos puedo calcular la media aritmetica
//		int32_t  b ;
//   		pVolt->ADmedia = 0;
//   		for ( b=0 ; b <= Nbuffer; b++ )
//   			pVolt->ADmedia += pVolt->ADCbuffer[b];
//
//   		pVolt->ADmediaDisplay = pVolt->ADmedia / Nbuffer;
//		#else
//
//   		pVolt->ADmediaDisplay = pVolt->ADmedia >> Nbit;  			// cambio formato para visualizar display
//		#endif
//
//    Vvalor=ADtoVolt(pVolt->ADmediaDisplay, EscalaNume*Ndig, EscalaDeno);
//    QmnToString(Vvalor, 3, 6, buf, 10);
//    UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//    UART_Send(LPC_UART3, " v", sizeof(" v"), BLOCKING);
//    UART_SendByte(LPC_UART3,'\t');
//
//
//    ADmediaDisplay = pVolt->ADeficazAC >> Nbit;  		// cambio formato para visualizar display
//    Vvalor = ADtoVolt(ADmediaDisplay, EscalaNume*Ndig, EscalaDeno);
//    QmnToString(Vvalor, 3, 6, buf, 10);
//    UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//    UART_Send(LPC_UART3, " v", sizeof(" v"), BLOCKING);
//    UART_SendByte(LPC_UART3,'\t');
//
//
//    intToString(pVolt->NadDisplay, buf, 10, 10);
//    UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//    UART_SendByte(LPC_UART3,'\t');
//
//
//    intToString(pVolt->Error, buf, 10, 10);
//    UART_Send(LPC_UART3,buf, sizeof(buf), BLOCKING);
//
//
//    UART_Send(LPC_UART3, MessageCursorOFF, sizeof(MessageCursorOFF), BLOCKING);
//
//
//    UART_SendByte(LPC_UART3,'\r');
//    UART_SendByte(LPC_UART3,'\n');
//    UART_Send(LPC_UART3, MessageValues, sizeof(MessageValues), BLOCKING);

}
//==============================================================================================



//==============================================================================================
void MostrarValor(typeVoltimetro * pVolt)
{
	//tamaño del display   96 x 64
	uint8_t x = 1 , y = 1;     						//coordenadas en el display

	uint8_t buf[11];
	fxp32_escalaAD Vvalor;									// auxiliar temporal
	fxp32_escalaMediaN ADmediaDisplay; 						// auxiliar temporal


	x = (1+5*8) , y = 1 ;
	MyIntToString(pVolt->ADvalor, buf, 10, 10);
	oled_fillRect(x , y , x+80, y+7, OLED_COLOR_BLACK);		// borro el texto anterior
 	oled_putString(x, y , buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

 	x = (1+5*7) , y = 9 ;
	Vvalor=ADtoVolt(pVolt->ADvalor, EscalaNume, EscalaDeno);
	QmnToString(Vvalor, 3, 3, buf, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);


	x = (1+5*7) , y = 17 ;
	Vvalor=ADtoVolt(pVolt->ADmax, EscalaNume, EscalaDeno);
	QmnToString(Vvalor, 3, 3, buf, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

	x = (1+5*7) , y = 25 ;
	Vvalor=ADtoVolt(pVolt->ADmin, EscalaNume, EscalaDeno);
	QmnToString(Vvalor, 3, 3, buf, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

	#if MEDIA_ARITME
  		// recien ahora con todos los datos puedo calcular la media aritmetica
		int32_t  b ;
   		pVolt->ADmedia = 0;
   		for ( b=0 ; b <= Nbuffer; b++ )
   			pVolt->ADmedia += pVolt->ADCbuffer[b];

   		pVolt->ADmediaDisplay = pVolt->ADmedia / Nbuffer;
	#else

   		pVolt->ADmediaDisplay = pVolt->ADmedia >> Nbit;  			// cambio formato para visualizar display
	#endif

   	x = (1+5*7) , y = 33 ;
   	Vvalor=ADtoVolt(pVolt->ADmediaDisplay, EscalaNume*Ndig, EscalaDeno);
   	QmnToString(Vvalor, 3, 6, buf, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

	x = (1+5*7) , y = 41 ;
    ADmediaDisplay = pVolt->ADeficazAC >> Nbit;  		// cambio formato para visualizar display
    Vvalor = ADtoVolt(ADmediaDisplay, EscalaNume*Ndig, EscalaDeno);
   	QmnToString(Vvalor, 3, 6, buf, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);

	x = (1+5*8) , y = 49 ;
    MyIntToString(pVolt->NadDisplay, buf, 10, 10);
	oled_fillRect(x,y, x+80, y+7, OLED_COLOR_BLACK);
 	oled_putString(x,y, buf, OLED_COLOR_WHITE, OLED_COLOR_BLACK);


}

//========== FIN ====================================================================================
