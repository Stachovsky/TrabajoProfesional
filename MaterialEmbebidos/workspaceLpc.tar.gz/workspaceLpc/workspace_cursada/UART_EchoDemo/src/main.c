/*
===============================================================================
 Name        : main.c
 Author      : Alan Kharsansky <akharsa@gmail.com>
 Version     : 1.0
 Copyright   : Copyright (C) 
 Description : Blinky led using uC registers directly
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "lpc17xx_uart.h"
#include "lpc17xx_pinsel.h"

#include <string.h>

#include <cr_section_macros.h>
#include <NXP/crp.h>
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

const char welcome[]={"LPC1768 encendido...\r\n"};

int main(void) {
	PINSEL_CFG_Type PinCfg;
	UART_CFG_Type UARTConfigStruct;
	char c;

	PinCfg.Funcnum = PINSEL_FUNC_2;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_TRISTATE;
	PinCfg.Pinnum = PINSEL_PIN_0;
	PinCfg.Portnum = PINSEL_PORT_0;

	PINSEL_ConfigPin(&PinCfg);

	PinCfg.Pinnum = PINSEL_PIN_1;

	PINSEL_ConfigPin(&PinCfg);

	// Configuramos la UART
	UARTConfigStruct.Baud_rate = 115200;
	UARTConfigStruct.Databits = UART_DATABIT_8;
	UARTConfigStruct.Parity = UART_PARITY_NONE;
	UARTConfigStruct.Stopbits = UART_STOPBIT_1;

	// Inicializamos la UART
	UART_Init(LPC_UART3, &UARTConfigStruct);
	UART_TxCmd(LPC_UART3, ENABLE);


	// Mensaje de bienvenida
	UART_Send(LPC_UART3, welcome, strlen(welcome), BLOCKING);

	while(1) {

		// Leo un dato nuevo
		c = UART_ReceiveByte(LPC_UART3);

		if (c!=0){
			// Envio el dato leido
			UART_SendByte(LPC_UART3,c);
		}
	}
	return 0 ;
}

// Test comment
