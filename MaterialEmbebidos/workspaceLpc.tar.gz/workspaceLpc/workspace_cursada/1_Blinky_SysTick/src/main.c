/*
===============================================================================
 Name        : main.c
 Author      : Alan Kharsansky <akharsa@gmail.com>
 Version     : 1.0
 Copyright   : Copyright (C) 
 Description : Blinky led using the SysTick and GPIO drivers
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "lpc17xx_gpio.h"
#include "lpc17xx_systick.h"

#include <cr_section_macros.h>
#include <NXP/crp.h>
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

FunctionalState Cur_State = ENABLE;

int main(void) {
	
	//Use P0.22 to test System Tick interrupt
	GPIO_SetDir(0, (1<<22), 1);

	//Initialize System Tick with 10ms time interval
	//WARNING: Check the param allowed range!!!
	SYSTICK_InternalInit(10);
	//Enable System Tick interrupt
	SYSTICK_IntCmd(ENABLE);
	//Enable System Tick Counter
	SYSTICK_Cmd(ENABLE);

	// Endless loop
	while(1);

	return 1;
}


void SysTick_Handler(void)
{
	//Clear System Tick counter flag
	SYSTICK_ClearCounterFlag();

	//toggle P0.22
	if (Cur_State == ENABLE)
	{
		// Apagar pin
		GPIO_ClearValue(0, (1<<22));
		Cur_State = DISABLE;
	}
	else
	{
		// Prender pinc
		GPIO_SetValue(0, (1<<22));
		Cur_State = ENABLE;
	}
}
