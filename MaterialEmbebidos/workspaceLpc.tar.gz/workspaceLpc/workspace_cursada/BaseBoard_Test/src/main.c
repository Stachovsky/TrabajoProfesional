/*
===============================================================================
 Name        : main.c
 Author      : Alan Kharsansky
 Version     : 1.0
 Copyright   : Copyright (C)
 Description :
===============================================================================
*/
#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "baseboard.h"

int main(void) {

	initBaseBoard();

	int i,j,k;
	uint8_t barra;

	// Debuggear paso por paso para ver los leds indep
	RGB_Off();

	RGB_blueLedOn();
	RGB_blueLedOff();
	RGB_redLedOn();
	RGB_redLedOff();
	RGB_greenLedOn();
	RGB_greenLedOn();

	// Dejarlo prendido para poder usar el OLED! comparten el pin
	RGB_greenLedOn();

	while(1) {
		for (i=0;i<10;i++){
			led7segDisplay(i);
			//96 x 64
			oled_clearScreen(OLED_COLOR_WHITE);

			oled_putString(1,0,  "Pote: ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
			oled_putNumber(40,0,readPote(),OLED_COLOR_BLACK,OLED_COLOR_WHITE);

			oled_putString(1,10,  "Luz: ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
			oled_putNumber(40,10,light_read(),OLED_COLOR_BLACK,OLED_COLOR_WHITE);

			UART_SendString("hola: ");
			UART_SendNumber(i);
			UART_SendString("\r\n");

			barra = 0;
			for (k=0;k<(readPote()/512);k++){
				barra |= (1<<k);
			}

			redLedBarSet(barra);
			greenLedBarSet(1<<i);

			for (j=0;j<1000000;j++);

		}
	}

	return 0 ;
}
