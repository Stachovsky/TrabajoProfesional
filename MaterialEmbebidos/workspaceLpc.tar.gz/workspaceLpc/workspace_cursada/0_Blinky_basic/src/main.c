/*
===============================================================================
 Name        : main.c
 Author      : Alan Kharsansky <akharsa@gmail.com>
 Version     : 1.0
 Copyright   : Copyright (C) 
 Description : Blinky led using uC registers directly
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif


#include "lpc17xx_gpio.h"


int main(void) {
	int i;
	
	GPIO_SetDir(2 ,(1<<0) ,1);
	GPIO_SetDir(2 ,(1<<1) ,1);
	GPIO_SetDir(0 ,(1<<26) ,1);

	while (1) {
		int i ;
		GPIO_SetValue(2 ,(1<<0));
		for( i =0; i <10000000; i ++);
		GPIO_SetValue(2 ,(1<<1));
		for( i =0; i <10000000; i ++);
		GPIO_SetValue(0 ,(1<<26));

		for( i =0; i <10000000; i ++);
		GPIO_ClearValue(2 ,(1<<0));

		for( i =0; i <10000000; i ++);
		GPIO_ClearValue(2 ,(1<<1));

		for( i =0; i <10000000; i ++);
		GPIO_ClearValue(0 ,(1<<26));
		for( i =0; i <10000000; i ++);
	}
	return 0 ;
}

// Test comment
