/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "baseboard.h"

// IMPORTANTE: El jumper J28 NO debe estar colocado en el baseboard
#define PB_PORT 	1
#define PB_BIT 		(1UL << 31)

#define PULSADOR (!((GPIO_ReadValue(PB_PORT)) & PB_BIT))

void vTarea (void *pvParameters);

/*-----------------------------------------------------------*/

int main( void )
{

	initBaseBoard();

	xTaskCreate(
			vTarea,						/* Pointer to the function that implements the task. */
			"TAREA",					/* Text name for the task.  This is to facilitate debugging only. */
			configMINIMAL_STACK_SIZE,	/* Stack depth in words. */
			(void*) 0,					/* Parametro de la tarea */
			1,							/* Prioridad */
			NULL );						/* Task handle. */

	/* Start the scheduler so our tasks start executing. */
	vTaskStartScheduler();

	/* If all is well we will never reach here as the scheduler will now be
	running.  If we do reach here then it is likely that there was insufficient
	heap available for the idle task to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

// TAREA: Tarea genérica
void vTarea (void *pvParameters)
{
	// Inicialización

	// Task loop
	for ( ; ; ) {
		vTaskDelay(1/portTICK_RATE_MS);
	}

}
