/*
===============================================================================
 Name        : main.c
 Author      :
 Version     : 1.0
 Copyright   : Copyright (C)
 Description : Template de proyecto. Para usarlo copiarlo y pegarlo.
===============================================================================
*/
#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

// El clock sources es el TICK del periferico:
#define	PWM_PRESCALER_US	1
#define PWM_PERIOD			1000/PWM_PRESCALER_US

#include "lpc17xx_pwm.h"
#include "lpc17xx_pinsel.h"


int main(void) {
	PINSEL_CFG_Type PinCfg;
	PWM_TIMERCFG_Type PWMCfgDat;
	PWM_MATCHCFG_Type PWMMatchCfgDat;

	//=========================================================
	// Configuración de los pines
	//=========================================================
	// Configuración del pin de PWM, GPIO2.0 - PWM1.1
	PinCfg.Funcnum = PINSEL_FUNC_1;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	PinCfg.Portnum = PINSEL_PORT_2;
	PinCfg.Pinnum = PINSEL_PIN_0;
	PINSEL_ConfigPin(&PinCfg);

	PinCfg.Funcnum = PINSEL_FUNC_1;
	PinCfg.OpenDrain = PINSEL_PINMODE_NORMAL;
	PinCfg.Pinmode = PINSEL_PINMODE_PULLUP;
	PinCfg.Portnum = PINSEL_PORT_0;
	PinCfg.Pinnum = PINSEL_PIN_3;
	PINSEL_ConfigPin(&PinCfg);

	//=========================================================
	// Configuración del timer
	//=========================================================
	//Configuración del modo de trabajo del modulo de PWM
	// Modo: Timer
	// Prescaler: PWM_PRESCALER
	PWMCfgDat.PrescaleOption = PWM_TIMER_PRESCALE_USVAL;
	PWMCfgDat.PrescaleValue = PWM_PRESCALER_US;
	PWM_Init(LPC_PWM1, PWM_MODE_TIMER, (void *) &PWMCfgDat);


	//=========================================================
	// Configuración del canal de Match 0 - PERIODO del PWM
	//=========================================================
	// Set match value for PWM match channel 0
	PWM_MatchUpdate(LPC_PWM1, 0, PWM_PERIOD/PWM_PRESCALER_US, PWM_MATCH_UPDATE_NOW);

	PWMMatchCfgDat.MatchChannel = 0;
	PWMMatchCfgDat.IntOnMatch = DISABLE;
	PWMMatchCfgDat.ResetOnMatch = ENABLE;
	PWMMatchCfgDat.StopOnMatch = DISABLE;
	PWM_ConfigMatch(LPC_PWM1, &PWMMatchCfgDat);

	//=========================================================
	// Configuración del canal de Match 1 - DUTY CYCLE
	//=========================================================

	// Channel 1
	//PWM_ChannelConfig(LPC_PWM1, 1, PWM_CHANNEL_SINGLE_EDGE);

	// Set up match value
	PWM_MatchUpdate(LPC_PWM1, 1, 0.5*PWM_PERIOD/PWM_PRESCALER_US, PWM_MATCH_UPDATE_NOW);

	// Configure match option
	PWMMatchCfgDat.MatchChannel = 1;
	PWMMatchCfgDat.IntOnMatch = DISABLE;
	PWMMatchCfgDat.ResetOnMatch = DISABLE;
	PWMMatchCfgDat.StopOnMatch = DISABLE;
	PWM_ConfigMatch(LPC_PWM1, &PWMMatchCfgDat);

	//=========================================================
	// Activo la salida del pwm
	//=========================================================
	// Enable PWM Channel Output */
	PWM_ChannelCmd(LPC_PWM1, 1, ENABLE);

	//=========================================================
	// Reseteo el estado inicial
	//=========================================================
	// Reset and Start counter
	PWM_ResetCounter(LPC_PWM1);
	PWM_CounterCmd(LPC_PWM1, ENABLE);

	//=========================================================
	// Enciendo el periférico
	//=========================================================
	PWM_Cmd(LPC_PWM1, ENABLE);

	int i = 0, value = 0;

	while(1) {

		for (i=0;i<10000;i++);

		value++;

		if (value==PWM_PERIOD){
			value = 0;
		}

		PWM_MatchUpdate(LPC_PWM1, 1, (value)/PWM_PRESCALER_US, PWM_MATCH_UPDATE_);
	}

	return 0 ;
}
