//P2.0 func 01 PWM1.1
//P2.1 func 01 PWM1.2
//P2.2 func 01 PWM1.3
//P2.3 func 01 PWM1.4
//P2.4 func 01 PWM1.5
//P2.5 func 01 PWM1.6