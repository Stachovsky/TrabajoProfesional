/*
===============================================================================
 Name        : main.c
 Author      :
 Version     : 1.0
 Copyright   : Copyright (C)
 Description : Template de proyecto. Para usarlo copiarlo y pegarlo.
===============================================================================
*/
#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include "baseboard.h"

int main(void) {

	while(1) {
	}

	return 0 ;
}
